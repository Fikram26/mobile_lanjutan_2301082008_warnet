package com.example.flutter_warnet1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
